import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import sidebarJsonUrl from '../../assets/jsondata/sidebar.json'

@Injectable({
    providedIn: 'root'
})

export class SideBarValidationService {

    getSideBarValidationData(): Observable<any> {
        return this.createObservableObj(sidebarJsonUrl);
    }

    createObservableObj(sidebarJsonUrl: string) {
        const sidebarData = new Observable(observer => {
            observer.next(sidebarJsonUrl);
            observer.complete();
        });
        return sidebarData;
    }
}
