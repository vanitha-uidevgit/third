import { Component, Input, OnInit } from '@angular/core';
import { SideBarValidationService } from '../../../services/sidebar.service';

@Component({
  selector: 'app-document-list-section',
  templateUrl: './document-list-section.component.html',
  styleUrls: ['./document-list-section.component.scss']
})
export class DocumentListSectionComponent implements OnInit {

  public sidebarData: any;
  public _sidebarSize: string =  '420px';
  @Input() docListViewStatus : any;

  constructor(private sidebarService: SideBarValidationService) { }

  ngOnInit(): void {

    this.sidebarService.getSideBarValidationData().subscribe((data: any) => {

      if (data) {
        this.sidebarData = data;
      }
    });
  }

  sizeChange(size: any){
    console.log(this._sidebarSize, size);
  }

}
