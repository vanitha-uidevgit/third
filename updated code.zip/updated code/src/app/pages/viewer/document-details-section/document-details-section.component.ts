import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-document-details-section',
  templateUrl: './document-details-section.component.html',
  styleUrls: ['./document-details-section.component.scss']
})
export class DocumentDetailsSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
