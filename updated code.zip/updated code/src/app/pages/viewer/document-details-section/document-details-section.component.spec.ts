import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentDetailsSectionComponent } from './document-details-section.component';

describe('DocumentDetailsSectionComponent', () => {
  let component: DocumentDetailsSectionComponent;
  let fixture: ComponentFixture<DocumentDetailsSectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentDetailsSectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentDetailsSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
